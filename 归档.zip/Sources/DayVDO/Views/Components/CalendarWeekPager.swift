import SwiftUI

/// A native horizontal viewport; each target is one complete week. Keep a
/// bounded virtual range and rebase only at rest, as the month timeline does.
struct CalendarWeekPager<Content: View>: View {
    let week: LocalDay
    var selectWeek: (LocalDay) -> Void
    @ViewBuilder var content: (LocalDay) -> Content
    @State private var anchor: LocalDay?
    @State private var position = ScrollPosition(idType: LocalDay.self)
    @State private var visibleWeek: LocalDay?
    @State private var isScrolling = false
    private let radius = 52

    var body: some View {
        GeometryReader { geometry in
            let origin = anchor ?? week
            ScrollView(.horizontal) {
                LazyHStack(spacing: 0) {
                    ForEach(-radius...radius, id: \.self) { index in
                        let day = origin.adding(days: index * 7)
                        content(day)
                            .frame(width: geometry.size.width, height: geometry.size.height)
                            .id(day)
                    }
                }
                .scrollTargetLayout()
            }
            .scrollIndicators(.hidden)
            .scrollClipDisabled()
            .scrollPosition($position)
            .defaultScrollAnchor(.center, for: .initialOffset)
            .scrollTargetBehavior(.paging)
            .onScrollGeometryChange(for: Int.self) { value in
                guard value.containerSize.width > 0 else { return 0 }
                return Int(((value.contentOffset.x + value.contentInsets.leading)
                    / value.containerSize.width).rounded()) - radius
            } action: { _, index in
                visibleWeek = origin.adding(days: min(radius, max(-radius, index)) * 7)
            }
            .onScrollPhaseChange { _, phase in
                isScrolling = phase != .idle
                if phase == .idle, let visibleWeek {
                    if visibleWeek != week { selectWeek(visibleWeek) }
                    if abs(origin.distance(to: visibleWeek)) >= (radius - 4) * 7 {
                        recenter(on: visibleWeek)
                    }
                }
            }
            .onAppear {
                if anchor == nil { recenter(on: week) }
            }
            .onChange(of: week) { _, target in
                guard target != visibleWeek || !isScrolling else { return }
                if abs(origin.distance(to: target)) > (radius - 4) * 7 {
                    recenter(on: target)
                } else {
                    position.scrollTo(id: target, anchor: .leading)
                }
            }
            .onChange(of: geometry.size.width) { _, width in
                position.scrollTo(x: CGFloat(radius + origin.distance(to: week) / 7) * width)
            }
        }
    }

    private func recenter(on day: LocalDay) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            anchor = day
            visibleWeek = day
            position.scrollTo(id: day, anchor: .leading)
        }
    }
}
