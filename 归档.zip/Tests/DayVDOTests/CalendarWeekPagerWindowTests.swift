import AppKit
import SwiftUI
import XCTest
@testable import DayVDO

@MainActor
final class CalendarWeekPagerWindowTests: XCTestCase {
    func testHorizontalGestureSnapsWholeWeeksAndVerticalScrollStaysInItsPane() async throws {
        _ = NSApplication.shared
        let probe = WeekPagerProbe()
        let host = NSHostingView(rootView: WeekPagerHarness(probe: probe))
        let window = NSWindow(contentRect: NSRect(x: 50, y: 50, width: 700, height: 500),
                              styleMask: [.titled], backing: .buffered, defer: false)
        window.isReleasedWhenClosed = false
        window.contentView = host
        window.orderFront(nil)
        defer { window.contentView = nil; window.close() }
        try await settle(host)
        let pager = try XCTUnwrap(scrollViews(host).first { ($0.documentView?.bounds.width ?? 0) > 1400 })
        let initialX = pager.contentView.bounds.minX
        XCTAssertEqual(initialX, 52 * 700, accuracy: 1)
        for sign: CGFloat in [-1, 1] {
            let pane = try XCTUnwrap(scrollViews(host).first {
                $0 !== pager && $0.convert($0.bounds, to: host).contains(CGPoint(x: 350, y: 250))
            })
            // Feed a native trackpad sequence into the real paged scroll view.
            for step in 0...20 {
                let phase: Int64 = step == 0 ? 1 : (step == 20 ? 4 : 2)
                let delta = step == 0 || step == 20 ? 0 : sign * 40
                pane.scrollWheel(with: wheel(dx: delta, dy: 0, phase: phase))
                try await Task.sleep(for: .milliseconds(12))
            }
            try await settle(host)
            let offset = pager.contentView.bounds.minX / 700
            XCTAssertEqual(offset, offset.rounded(), accuracy: 0.01)
            XCTAssertEqual(probe.week, probe.original.adding(days: sign < 0 ? 7 : 0))
        }
        XCTAssertEqual(pager.contentView.bounds.minX, initialX, accuracy: 1)
        let pane = try XCTUnwrap(scrollViews(host).first {
            $0 !== pager && $0.convert($0.bounds, to: host).contains(CGPoint(x: 350, y: 250))
        })
        for step in 0...10 {
            pane.scrollWheel(with: wheel(dx: 0, dy: step == 0 || step == 10 ? 0 : -25,
                                        phase: step == 0 ? 1 : (step == 10 ? 4 : 2)))
            try await Task.sleep(for: .milliseconds(12))
        }
        try await settle(host)
        XCTAssertGreaterThan(pane.contentView.bounds.minY, 100)
        XCTAssertEqual(pager.contentView.bounds.minX, initialX, accuracy: 1)
        XCTAssertEqual(probe.week, probe.original)
        probe.week = probe.original.adding(days: 700)
        try await settle(host)
        XCTAssertEqual(pager.contentView.bounds.minX, initialX, accuracy: 1,
                       "Distant date navigation rebases onto a centered week")
        window.setContentSize(NSSize(width: 850, height: 500))
        try await settle(host)
        XCTAssertEqual(pager.contentView.bounds.minX, 52 * 850, accuracy: 1)
    }

    private func wheel(dx: CGFloat, dy: CGFloat, phase: Int64) -> NSEvent {
        let event = CGEvent(scrollWheelEvent2Source: nil, units: .pixel, wheelCount: 2,
                            wheel1: Int32(dy), wheel2: Int32(dx), wheel3: 0)!
        event.setIntegerValueField(.scrollWheelEventScrollPhase, value: phase)
        return NSEvent(cgEvent: event)!
    }

    private func scrollViews(_ view: NSView) -> [NSScrollView] {
        ((view as? NSScrollView).map { [$0] } ?? []) + view.subviews.flatMap(scrollViews)
    }
    private func settle(_ view: NSView) async throws {
        for _ in 0..<35 {
            view.layoutSubtreeIfNeeded()
            try await Task.sleep(for: .milliseconds(20))
        }
    }
}

@MainActor
private final class WeekPagerProbe: ObservableObject {
    let original = LocalDay(year: 2026, month: 10, day: 12)
    @Published var week = LocalDay(year: 2026, month: 10, day: 12)
}
private struct WeekPagerHarness: View {
    @ObservedObject var probe: WeekPagerProbe
    var body: some View {
        CalendarWeekPager(week: probe.week, selectWeek: { probe.week = $0 }) { day in
            ScrollView(.vertical) {
                Text(verbatim: String(describing: day)).frame(maxWidth: .infinity).frame(height: 2000)
            }
        }
    }
}
